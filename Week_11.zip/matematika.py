phi  = 3.14

def llingkaran () :
    jari2         = float (input ("Masukkan Jari-Jari Lingkaran = "))
    return phi * jari2 * jari2

def lpersegi   () :
    sisi          = float (input ("Masukkan sisi persegi        = "))
    return sisi * sisi
